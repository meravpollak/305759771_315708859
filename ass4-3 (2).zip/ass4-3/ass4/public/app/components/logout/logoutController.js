/**
 * Created by MERAV on 05/08/2017.
 */

app.controller('logoutController', ['localStorageService','UserService','$window','$location',function (localStorageService,UserService,$window,$location) {

    let self = this;
    self.UserService = UserService;

    //logout from the web
    self.logout=function() {
        self.UserService.isLoggedIn=false;
        $window.alert(UserService.UserName +' logout successfully');
        localStorageService.cookie.clearAll();
        localStorageService.clearAll();
        window.location.reload();
        $location.path('/home');
    }
}]);