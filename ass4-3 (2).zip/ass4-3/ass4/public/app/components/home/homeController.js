app.controller('homeController', ['cartService','localStorageService','UserService','$http','$scope','$location', function (cartService,localStorageService,UserService,$http,$scope,$location) {

    let ctrl = this;
    ctrl.UserService=UserService;
    ctrl.products=[0];
    ctrl.productsNew=[0];
    ctrl.fieldToOrderBy="Name";
    ctrl.cartService=cartService;
    getHotProduct();

    if(ctrl.UserService.isLoggedIn){
        getNewProduct();
    }


    ctrl.Login=function(){
        $scope.username="Guest";
        var userIsLOG =  decodeURIComponent(document.cookie);
        if(userIsLOG!="") {
            ctrl.UserService.isLoggedIn = true;
            ctrl.UserService.UserName=userIsLOG.substring(2,userIsLOG.indexOf("="));
            $scope.username=ctrl.UserService.UserName;
            var date = new Date();
            var dateAsString = date.toString();
            dateAsString = dateAsString.substring(0, dateAsString.indexOf("G"));
            ctrl.UserService.LoginAt = dateAsString;
        }
    };

    function getHotProduct(){
        $http.get('/HotProductsForDisplay').then(function (response) {
            var returnData = response.data;
            ctrl.products = returnData;
            console.log(ctrl.products);
        }, function (errResponse) {
            console.error('Error while fetching products');
        });
    };

    function getNewProduct() {
        $http.get('/NewProductForDisplay').then(function (response) {
            var returnData = response.data;
            ctrl.productsNew = returnData;
            console.log(ctrl.productsNew);
        }, function (errResponse) {
            console.error('Error while fetching products');
        });
    };

    ctrl.getToCart=function(){
        $location.path('/cart');
    };

}]);