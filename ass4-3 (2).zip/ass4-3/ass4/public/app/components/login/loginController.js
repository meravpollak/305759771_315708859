

app.controller('loginController', ['localStorageService','UserService', '$http' ,'$location', '$window',
    function(localStorageService,UserService, $http, $location, $window) {
        let self = this;
        self.user = {UserName: '', Password: ''};
        self.retrivalQuestion="";
        self.retrivalAnswer="";
        self.showAnswer=false;
        self.UserService=UserService;

        self.login = function(valid) {
            if (valid) {

                self.UserService.login(self.user)
                    .then(function (success) {
                    if(success.data.result==true)
                    {
                        $window.alert('You are logged in successfully');
                        var name = "c" + self.user.UserName + "=";
                        getCookie(name, $window , localStorageService , self.user.UserName , self.user.Password);
                        $location.path('/home');
                    }
                    else
                    {
                        $window.alert('login has failed');
                    }
                }, function (error) {
                    self.errorMessage = error.data;
                    $window.alert('log-in has failed');
                })
            }
        };

        self.getQuestion = function()
        {
            requestUrl = "/RetrievalPasswordQuestion/" + self.user.UserName;
            $http.get(requestUrl).then(function (response) {
                var returnData = response.data;
                self.retrivalQuestion = returnData.result[0].Question;
                console.log(self.Question);
                self.showAnswer=true;
            }, function (errResponse) {
                console.error('Error while retrival question');

            });
        };

        self.getPassword = function()
        {
            var User={UserName: self.user.UserName, Answer: self.retrivalAnswer};
            $http.post('/RetrievalPassword-Password',User).then(function (response) {
                var returnData = response.data;
                self.user.Password = returnData.result[0].Password;
                console.log(self.user.Password);
                $window.alert("Your password is: "+self.user.Password);
            }, function (errResponse) {
                console.error('Error while retrival password');
            });
        };
    }]);

function getCookie(cname , $window , localStorageService , username, password) {
    let cookie = "";
    var name = cname;
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            cookie = c.substring(name.length, c.length);
        }
    }
    if (cookie == "")
    {
        if (localStorageService.cookie.set(username, password), 2)
        {
           window.location.reload();
        }
        else
            $window.alert('cookie was failed in adding to Storage');
    }
    else
        $window.alert('cookie already added');
}