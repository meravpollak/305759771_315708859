/**
 * Created by MERAV on 02/08/2017.
 */

app.controller('productsViewController',['$http','cartService','UserService',function($http ,cartService,UserService ) {
    let vm=this;
    vm.productsForCategory=[];
    vm.cartService = cartService;
    vm.category="all";
    vm.categoryID='';
    vm.fieldToOrderBy="name";
    vm.recomendedProducts=[];
    vm.UserService=UserService;
    //change the category
    vm.changeCategory= function(CategoryToChange) {
        vm.getProductsByCat();
    }

    //change the products for a specific category
    vm.getProductsByCat=function() {
        if(vm.category=="all")
        {
            var requestUrl = '/getProductlist'
            $http.get(requestUrl).then(function (response) {
                vm.productsForCategory = response.data.result;
                //  console.log("products in categoryID:" + CategoryIDtoChange + " " + vm.productsForCategory);
                for(var i=0;i<vm.productsForCategory.length;i++)
                {
                    if(vm.productsForCategory[i].CategoryID==1)
                        vm.productsForCategory[i].CategoryID="box games";
                    if(vm.productsForCategory[i].CategoryID==2)
                        vm.productsForCategory[i].CategoryID="dolls&heroes";
                    if(vm.productsForCategory[i].CategoryID==3)
                        vm.productsForCategory[i].CategoryID="creativity games";
                    if(vm.productsForCategory[i].CategoryID==4)
                        vm.productsForCategory[i].CategoryID="construction toys";
                }
            }, function (errResponse) {
                console.error('Error get the products for this category');
            });
        }
        else {
            if(vm.category=="box games")
                vm.categoryID=1;
            else if(vm.category=="dolls&heroes")
                vm.categoryID=2;
            else if(vm.category=="creativity games")
                vm.categoryID=3;
            else if(vm.category=="construction toys")
                vm.categoryID=4;
            var requestUrl = "/getProductlistByCategory/" + vm.categoryID;
            $http.get(requestUrl).then(function (response) {
                vm.productsForCategory = response.data.result;
                for(var i=0;i<vm.productsForCategory.length;i++)
                {
                        vm.productsForCategory[i].CategoryID=vm.category;
                }
                //  console.log("products in categoryID:" + CategoryIDtoChange + " " + vm.productsForCategory);
            }, function (errResponse) {
                console.error('Error get the new products for this categoryID');
            });
        }

    }
    vm.getRecomended = function () {
        if(vm.UserService.isLoggedIn)
        {
            var requestUrl = "/getCategoryByUserName/" + vm.UserService.UserName;
            $http.get(requestUrl).then(function (response) {
                vm.UserService.Category = response.data.result[0].CategoryName;
                getProducts();
            }, function (errResponse) {
                console.error('Error get the category for this UserName');
            });

        }
    }
    function getProducts()
    {
        if(vm.UserService.Category=="box games")
            vm.UserService.CategoryID=1;
        else if(vm.UserService.Category=="dolls&heroes")
            vm.UserService.CategoryID=2;
        else if(vm.UserService.Category=="creativity games")
            vm.UserService.CategoryID=3;
        else if(vm.UserService.Category=="construction toys")
            vm.UserService.CategoryID=4;
        var requestUrl = "/getProductlistByCategory/" + vm.UserService.CategoryID;
        $http.get(requestUrl).then(function (response) {
            vm.recomendedProducts = response.data.result;
            //  console.log("products in categoryID:" + CategoryIDtoChange + " " + vm.productsForCategory);
        }, function (errResponse) {
            console.error('Error get the recomended products for this categoryID');
        });
    }
}]);



