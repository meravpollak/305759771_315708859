/**
 * Created by MERAV on 05/08/2017.
 */
app.controller('AboutController', ['$http','$window', function($http, $window) {

}]);