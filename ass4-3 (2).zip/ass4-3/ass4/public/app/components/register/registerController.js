app.controller('registerController', ['UserService','$location', '$window',
    function(UserService, $location, $window) {
        var self = this;
        self.countries=[];
        self.countries=Countries;
        self.selectedCountry=Countries[0];
        self.categories=categories;
        self.selectedCategory=categories[0];
        self.user = {UserName: '', Password: '', FirstName: '', LastName: '', Adress:'', City:'', Country:'',Cellular:'',Mail:'',CreditCardNumber:'',Question:'',Answer:''};
        self.register = function(valid) {
            if (valid) {
                self.user.Country=self.selectedCountry.Name;
                UserService.register(self.user).then(function (success) {
                    $window.alert('You are register');
                    $location.path('/login');
                }, function (error) {
                    self.errorMessage = error.data;
                    $window.alert('register has failed');
                })
                var userCategory={UserName: '',CategoryName:''};
                userCategory.UserName=self.user.UserName;
                userCategory.CategoryName = self.selectedCategory;
                $http.post('/FavoriteCategory',userCategory).then(function (response) {
                }, function (errResponse) {
                    console.error('Error to insert category to user');
                });
            }
        };
    }]);

var Countries = [{ID:"1",Name:"Australia"},{ID:"2",Name:"Bolivia"},{ID:"3",Name:"China"},{ID:"4",Name:"Denemark"},{ID:"5",Name:"Israel"},{ID:"6",Name:"Latvia"},{ID:"7",Name:"Monaco"},
    {ID:"8",Name:"August"},{ID:"9",Name:"Norway"},{ID:"10",Name:"Panama"},{ID:"11",Name:"Switzerland"},{ID:"12",Name:"USA"}];

var categories = [{ID:"1",Name:"box games"},{ID:"2",Name:"dolls&heroes"},{ID:"3",Name:"creativity games"},{ID:"4",Name:"construction toys"}];