

var app = angular.module('myApp', ['ngRoute','LocalStorageModule']);

app.config(function (localStorageServiceProvider) {
    localStorageServiceProvider.setPrefix('c');
});

app.config(['$locationProvider', function($locationProvider) {
    $locationProvider.hashPrefix('');
}]);
app.config( ['$routeProvider', function($routeProvider) {
    $routeProvider
        .when("/home", {
            templateUrl : "app/components/home/home.html",
            controller : "homeController"
        })
        .when("/login", {
            templateUrl : "app/components/login/login.html",
            controller : "loginController"
        })
        .when("/register", {
            templateUrl : "app/components/register/register.html",
            controller : "registerController"
        })
        .when("/products", {
            templateUrl : "app/components/products/productsView.html",
            controller : "productsViewController"
        })
        .when("/logout", {
            templateUrl : "app/components/logout/logout.html",
            controller : "logoutController"
        })
        .when("/About", {
            templateUrl : "app/components/About/About.html",
            controller : "AboutController"
        })
        .when("/cart", {
            templateUrl : "app/components/cart/cart.html",
            controller : "cartController"
        })
        .otherwise({redirectTo: '/home',
        });
}]);